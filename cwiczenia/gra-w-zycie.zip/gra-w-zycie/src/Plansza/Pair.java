package Plansza;

public class Pair {
    public int m, n;

    private Pair() {}

    public Pair(int m, int n) {
        this.m = m;
        this.n = n;
    }
}

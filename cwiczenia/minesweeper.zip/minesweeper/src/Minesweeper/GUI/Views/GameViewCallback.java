package Minesweeper.GUI.Views;

public interface GameViewCallback {
    void onMenuReturn();
}

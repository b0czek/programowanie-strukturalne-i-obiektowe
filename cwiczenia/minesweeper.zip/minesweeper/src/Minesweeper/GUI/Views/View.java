package Minesweeper.GUI.Views;

import javax.swing.*;

public abstract class View extends JPanel {
    public void onViewShown() {}
}

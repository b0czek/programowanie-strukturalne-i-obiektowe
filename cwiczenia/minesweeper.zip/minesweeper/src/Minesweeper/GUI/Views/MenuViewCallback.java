package Minesweeper.GUI.Views;

import Minesweeper.plansza.Difficulty;

public interface MenuViewCallback {
    void onDifficultySelect(Difficulty difficulty);
}

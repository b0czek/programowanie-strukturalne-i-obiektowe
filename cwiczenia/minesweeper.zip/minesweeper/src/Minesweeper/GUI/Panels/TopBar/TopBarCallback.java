package Minesweeper.GUI.Panels.TopBar;

public interface TopBarCallback {
    void onBackButton();
    void onResetButton();
}

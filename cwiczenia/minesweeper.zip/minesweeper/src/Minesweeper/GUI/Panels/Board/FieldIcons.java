package Minesweeper.GUI.Panels.Board;

public enum FieldIcons {
    Bomb,
    Flag

}

package Minesweeper.plansza;

public enum Stan {
    Odkryta, Zflagowana, Zakryta,
}


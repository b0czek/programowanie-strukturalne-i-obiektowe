package Minesweeper.plansza;public class lor {
  //  dawno dawno temu za gorami za lasami i rzekami zylo sobie stado kotkow. byly bardzo szczesliwee w swojej magicznej krainie slodkosci;
   // jednak pewnego dnia wydarzylo sie cos strasznego - zlowieszcze dinozaury przejely kraine zagarniajac sobie wszystie dobytki i zasoby kotkow.
  //  W ramach zemsty kotki nauczyly sie kamuflowac, tak aby byc nie widoczne dla wrogow. Dinozaury juz dawno opuscily wioske :((
  //  Kotki jednak nadal pozostaly w uspieniu, zakamuflowane w terenach krainy.
 //   Pomoz wydostac sie kotką z ukrycia i pokaz im prawdziwy swiat - jednak strzez sie!! jezeli zaatakujesz kota zdejmujac plyty ziemi - zostanies zabity kocia moca!!!
  //  powodzenia!!!
}

package Minesweeper;

public class ProjectInfo {
    public static final String TITLE = "CATSWEEPER";
    public static final String[] AUTHORS = { "Dariusz Majnert", "Natalia Marszałek", "Jarosław Sienkiewicz" };
}

import java.util.ArrayList;
import java.util.Random;
import java.util.stream.IntStream;

public class DariuszMajnert {

    public static double sinh(double x) {
        double result = x;
        double factorial = 1;
        for(int i = 3; i <= 20; i+=2) {
            factorial = factorial * (i-1) * i;
            double element = Math.pow(x,i) / factorial;
            result += element;
        }
        return result;
    }

    public static Matrix multiply(Matrix m1, Matrix m2) {
        if(m1.getN() != m2.getM()) {
            throw new ArithmeticException("invalid matrix size");
        }

        int[][] outputMatrix = new int[m1.getM()][m2.getN()];


        for(int i = 0; i < m1.getM(); i++) {
            for(int j = 0 ; j < m2.getN(); j++) {
                int sum = 0;
                for(int k = 0; k < m1.getN(); k ++) {
                    sum += m1.getValue(i, k) * m2.getValue(k, j);
                }
                outputMatrix[i][j] = sum;
            }
        }
        return new Matrix(outputMatrix);

    }

    public static void main(String[] args) {
        System.out.println("sinh(pi) = " + sinh(Math.PI));

        int[][] arr = new int[5][3];
        int[][] arr2 = new int [3][5];
        // random matrix values
        Random generator = new Random();
        for(int i = 0; i < arr.length; i++) {
            for(int j = 0; j < arr[0].length; j++) {
                arr[i][j] = generator.nextInt(10);
                arr2[j][i] = generator.nextInt(10);
            }
        }


        Matrix m = new Matrix(arr);
        Matrix m2= new Matrix(arr2);
        m.Show();
        System.out.println("");
        m2.Show();
        System.out.println("");
        m.add(m).Show();
        System.out.println("");
        multiply(m,m2).Show();


        ArrayList<Mouse> myMouses = new ArrayList<>();

        myMouses.add(new Mouse(1, "Konstanty", 20, 20));
        myMouses.add(new Mouse(2, "Bogusław", 15, 15));
        myMouses.add(new Mouse(3, "Gniewomir", 10, 10));
        myMouses.add(new Mouse(4, "Kazimierz", 5, 5));
        myMouses.add(new Mouse(5, "Lechosław", 3, 3));

        myMouses.forEach(mouse -> System.out.println(mouse));
        System.out.println();
        Cat cat = new Cat(5, "Maurycy", 14, 40, 9);

        myMouses.forEach(mouse -> {
            cat.chase(mouse);
            System.out.println(mouse);
        });


    }
}

import java.util.Arrays;

public class Matrix {
    private int n,m;
    private int[][] values;

    public Matrix(int[][] tab) {
        this.values = tab.clone();
        this.m = this.values.length;
        this.n = this.values[0].length;
    }

    public Matrix(int[] tab) {
        this.values = new int[1][];
        this.values[0] = tab.clone();
        this.m = 1;
        this.n = tab.length;
    }

    public void Show() {
        for(int i = 0; i < values.length; i++) {
            for(int j = -1; j <= values[i].length; j++) {
                if(j == -1 || j == values[i].length) {
                    System.out.print("|");
                }
                else {
                    System.out.printf("%10d", values[i][j]);
                }
            }
            System.out.println();
        }
    }
    public Matrix add(Matrix matrix) {
        if(matrix.getM() != this.getM() || matrix.getN() != this.getN()) {
            throw new ArithmeticException("cannot add a matrix of different size");
        }
        int[][] matrixValues = matrix.getValues();
        int[][] newMatrix = this.values.clone();

        for(int i = 0; i < this.getM(); i++) {
            for(int j = 0; j < this.getN(); j ++) {
                newMatrix[i][j] += matrixValues[i][j];
            }
        }
        return new Matrix(newMatrix);

    }

    public int getM() {
        return m;
    }

    public int getN() {
        return n;
    }

    public int[][] getValues() {
        return values;
    }
    public int getValue(int m, int n) {
        return this.values[m][n];
    }
}

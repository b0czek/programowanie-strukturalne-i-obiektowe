public class Mouse extends Creature {
    public Mouse(int age, String name, int speed, int healthPoints) {
        super(age, name, speed,healthPoints);
    }

    @Override
    public String toString() {
        return String.format("mouse %s, age: %d, speed: %d, healthPoints: %d", this.getName(), this.getAge(), this.getSpeed(), this.getHealthPoints());

    }
}

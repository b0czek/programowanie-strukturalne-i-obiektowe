public class Creature {
    private int age;
    private String name;

    private int speed;
    private int healthPoints;

    public Creature(int age, String name, int speed, int healthPoints) {
        this.age = age;
        this.name = name;
        this.speed = speed;
        this.healthPoints = healthPoints;

    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getHealthPoints() {
        return healthPoints;
    }

    public void setHealthPoints(int healthPoints) {
        this.healthPoints = healthPoints;
    }
}

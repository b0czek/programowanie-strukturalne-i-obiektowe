public class Cat extends Creature{
    private int power;


    public Cat(int age, String name, int speed, int healthPoints, int power) {
        super(age, name, speed,healthPoints);
        this.power = power;
    }

    public void chase(Mouse mouse) {
        if(mouse.getSpeed() > this.getSpeed()) {
            mouse.setHealthPoints( mouse.getHealthPoints() + 1);
        }
        else {
            mouse.setHealthPoints( mouse.getHealthPoints() - this.power);

        }

    }

    @Override
    public String toString() {
        return String.format("cat %s, age: %d, speed: %d, power: %d, healthPoints: %d", this.getName(), this.getAge(), this.getSpeed(), this.power, this.getHealthPoints());
    }
}
